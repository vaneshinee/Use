// Closes the Responsive Menu on Menu Item Click

